﻿const request = require('supertest');
const app = require('../app');
const syncDatabase = require('../util/syncDatabase.js')

beforeAll(async () => {
  await syncDatabase(); // Chamada assíncrona para sincronizar as tabelas antes de iniciar os testes
});

// Test for Appointment Controller
const getAllAppointmentsTest = () => {
  test('Deve retornar todos os agendamentos', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Activity Controller
const getAllActivitiesTest = () => {
  test('Deve retornar todas as atividades', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Audio Controller
const getAllAudiosTest = () => {
  test('Deve retornar todos os áudios', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for HealthArticle Controller
const getAllHealthArticlesTest = () => {
  test('Deve retornar todos os artigos de saúde', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Meditation Controller
const getAllMeditationsTest = () => {
  test('Deve retornar todas as meditações', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Patient Controller
const getAllPatientsTest = () => {
  test('Deve retornar todos os pacientes', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Session Controller
const getAllSessionsTest = () => {
  test('Deve retornar todas as sessões', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

// Test for Video Controller
const getAllVideosTest = () => {
  test('Deve retornar todos os vídeos', async () => {
    const response = await request(app).get('/models');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
};

module.exports = {
  getAllAppointmentsTest,
  getAllActivitiesTest,
  getAllAudiosTest,
  getAllHealthArticlesTest,
  getAllMeditationsTest,
  getAllPatientsTest,
  getAllSessionsTest,
  getAllVideosTest
};
